# Simulation trajet RERB – APK

## Option A (sans rien installer) : GitHub
1. Crée un dépôt GitHub (privé ou public) et envoie-y TOUT le contenu de ce dossier
   (y compris le dossier caché `.github`).
2. Onglet **Actions** > « Build APK » (il se lance tout seul, ou *Run workflow*).
3. Au bout de ~5 min, ouvre l'exécution > section **Artifacts** > télécharge `RER-B-Lumieres-apk`.
4. Dézippe, copie `app-debug.apk` sur le Samsung, ouvre-le et autorise « sources inconnues ».

## Option B : sur ton PC
Prérequis : Node 20, Java 17, Android Studio (SDK).
Lance `./build-local.sh` (ou les commandes dedans). APK : `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- Contenu de l'appli : `www/` (index.html + audio).
- Les polices Google Fonts nécessitent internet ; hors ligne, une police de secours s'affiche.
