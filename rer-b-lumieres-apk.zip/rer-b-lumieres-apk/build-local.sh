#!/bin/sh
# Build local (nécessite Node 20, Java 17 et le SDK Android / Android Studio)
set -e
npm install
[ -d android ] || npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
echo "APK : android/app/build/outputs/apk/debug/app-debug.apk"
